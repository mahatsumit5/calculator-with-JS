function myPolicy() {
  var txt;

  if (
    confirm(
      "This website is Created By Sumit Mahat and I do not provide any consent for others to use this for their own purpose.Please agree before Visiting my website. Thank you for understanding."
    )
  ) {
    txt = "";
  } else {
    txt = "Please comply with our policy to vist our store";
  }
  document.getElementById("p2").innerHTML = txt;
}

// function to hide side menu bar when clicked

function onClicked() {
  var yes = document.getElementById("check");

  if (yes.checked == true) {
    return (document.getElementById("side-bar").style.display = "block");
  } else {
    return (document.getElementById("side-bar").style.display = "none");
  }
}
